function dispHello() {
    document.write("<code>This text is displayed by calling an external function:</code> <strong>Hello World!</strong>");

}