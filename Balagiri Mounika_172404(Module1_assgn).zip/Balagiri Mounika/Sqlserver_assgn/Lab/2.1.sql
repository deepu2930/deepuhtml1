1)
select Emp_Code,Emp_name,Dept_Name
,DATEDIFF(YEAR,Hiredate, GETDATE()) from Emp_172404 where DATEDIFF(YEAR,Hiredate, GETDATE())>18

2)select * from Book_Transaction

select * from book_master


SELECT BOOK_CODE,STAFF_CODE FROM BOOK_TRANSACTION WHERE EXP_RETURN_DATE=(SELECT EXP_RETURN_DATE FROM BOOK_TRANSACTION WHERE EXP_RETURN_DATE<ACTUAL_RETURN_DATE)

4)
SELECT * FROM STUDENT_MASTER 
WHERE MONTH(Stud_dob)=MONTH(getdate())
5)
select count(book_code) from book_master
6)
SELECT COUNT(Book_Code) Book_Count from Book_Master WHERE Book_Category='physics' and Book_Category='Chemistry'

7)Select COUNT(Stud_code) Count from book_transaction where exp_return_date =getdate()
8)SELECT (MIN(Salary) MINIMUN,MAX(Salary) MAXIMUN,SUM(Salary) TOTA_SAL,Avg(Salary) average FROM Staff_Master

9)SELECT emp.EmployeeID , emp.EmployeeName, mgr.EmpoyeeName
FROM Employee_172404 emp
INNER JOIN Employee mgr
ON emp.ManagerID = mgr.EmployeeID
SELECT * FROM Staff_Master
SELECT * FROM Student_Marks
10)
SELECT (Stud_Year)as Year,count(Stud_code) No_Of_Students_Passed from student_marks WHERE (subject1)>=60 AND (SUBJECT2)>=60 AND(subject3)>=60 
GROUP BY Stud_year

11)SELECT Dept_Name from department_master where dept_code IN (select dept_code from student_master  group by dept_code having count(stud_code)>10) 

12)SELECT SUM(BOOK_PRICE) SUM FROM BOOK_MASTER 
13)SELECT BOOK_NAME FROM BOOK_MASTER WHERE BOOK_CATEGORY IN(SELECT BOOK_CATEGORY FROM BOOK_MASTER WHERE BOOK_PRICE>1000)
select * from desig_master
14)select count(stud_code) count from student_master where dept_code=10 and student_doj=2018


select * from student_master