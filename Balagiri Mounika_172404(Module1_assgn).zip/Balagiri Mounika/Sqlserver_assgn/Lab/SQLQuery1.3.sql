1.3)
1) create table Customer_172404(iCustomerid int UNIQUE,Customername varchar(20) NOT NULL,Address1 varchar(30),Address2 varchar(30),Contactnumber varchar(12) NOT NULL,Postalcode varchar(10))
2)CREATE TABLE Employees_172404
(
EmployeeId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL
);
3)CREATE TABLE Contractors_172404
(
ContractorId INT NOT NULL PRIMARY KEY, Name NVARCHAR(255) NULL)

4)
CREATE TABLE dbo.TestRethrow_172404
(
ID INT PRIMARY KEY
);
