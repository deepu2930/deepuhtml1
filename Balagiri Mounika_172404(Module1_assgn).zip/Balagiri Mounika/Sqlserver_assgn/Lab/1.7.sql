1.   

select * from staff_master;
select * from staff_master_back;
sp_help staff_master

CREATE PROCEDURE proc_staffslryUpdate @staffcodes varchar(10)
as
declare
@variableone varchar(10),
@experience date,
@experienceyears varchar(5);
Begin
    If @staffcodes is null 
        Begin 
            throw 50008,'Invalid city',12
        end 
    else

    select @variableone=Salary,@experience=hiredate,@experienceyears=datediff(year,hiredate,GETDATE())  from staff_master where Staff_Code=@staffcodes;
    if @variableone is not null
        Begin 
         if @experienceyears>= 2 and @experienceyears<= 5
             begin
                update Staff_Master set salary=salary+((25*(salary))/100) where Staff_Code=@staffcodes;
             end 
         if @experienceyears> 5
            begin
                update Staff_Master set salary=salary+((20*(salary))/100) where Staff_Code=@staffcodes;
            end
         insert into staff_master_back select * from Staff_Master where Staff_Code=@staffcodes;
        end
end;


begin try
exec mouni_172404.Proc_staffsalaryUpdate '10001'
end try
begin catch
    print Error_Message()
end catch
2)
select * from Book_Transaction;

create Procedure Userdeffindproc_booktrans @bookCode varchar(10),@scode varchar(10)
as
declare
@variableone varchar(10), @variabletwo varchar(10),@variablethree varchar(10),@datevar varchar(10)
begin
if @bookCode is null and @scode is null
    begin
        throw 50008,'entered book and code invalid',12
    end
else
   select @variableone=book_name from Book_Master where Book_code=@bookcode;
   select @variabletwo=stud_code from Student_master where Stud_Code=@scode;
   select @variablethree=staff_code from Staff_Master where Staff_Code=@scode;
   if (@variableone is not null and (@variabletwo is not null or @variablethree is not null))
   begin
        select @datevar=datename(weekday,DATEADD(DAY,10,getdate())) 
        
        if @datevar= ('Sunday')
         begin
            insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
            values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,11,getdate()));
         end
        if @datevar='Saturday'
         begin
                insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
                values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,12,getdate()));
         end
        if @datevar not in ('Saturday','Sunday')
         begin
                insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
                values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,10,getdate()));
          end

    end
end;
begin try
exec Udproc_booktrans '10000003','1002'
end try
begin catch 
 print error_message()
end catch
