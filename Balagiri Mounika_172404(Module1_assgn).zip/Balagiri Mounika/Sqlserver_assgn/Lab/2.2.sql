1)select * from Staff_Master
select Staff_code,Staff_name,Salary

select case when Salary>=50000 then 'A'
            when Salary>=20000 and Salary<50000 then 'B'
            when Salary>=10000 and Salary<20000 then 'C'
            else 'D'
       end as Grade,Staff_Name,Salary from Staff_Master

--2
select * from Desig_master
select * from Staff_Master
select * from Department_master
select * from Book_Master
select * from Book_Transaction

select sm.staff_code,sm.Staff_Name,dsm.Design_Name,dpm.Dept_Name,bm.book_code,bm.book_name,bm.author,
5*(datediff(day,bt.Exp_Return_date,bt.Actual_Return_date)) as fine
from Desig_master dsm inner join Staff_Master sm on dsm.Design_Code = sm.Des_Code
inner join Department_master dpm on sm.Dept_Code = dpm.Dept_code 
inner join Book_Transaction bt on sm.Staff_Code=bt.Staff_code
inner join Book_Master bm on bm.Book_code=bt.Book_code 

--3
select * from Staff_Master 

select * from Staff_Master
where Mgr_code in( select Staff_Code from Staff_Master where Staff_Code = 100006) 
4)
select * from Student_master
select * from Department_master
select * from Desig_master
select * from Staff_Master 
select * from Book_Master
select * from Book_Transaction                                           

select stum.Stud_Name,dpm.Dept_Name
from Student_master stum inner join Department_master dpm on stum.Dept_Code = dpm.Dept_code
inner join Staff_Master stam on stam.Dept_Code = dpm.Dept_code
inner join Desig_master dsm on dsm.Design_Code =stam.Des_Code
inner join Book_Transaction bt on bt.Staff_code=stam.Staff_Code
where bt.Book_code in (select stam.staff_Code from Staff_Master
where dsm.Design_Code in(select dsm.Design_Name from Desig_master
where dsm.Design_Name='Professor'))
5)
select * from Book_Master
select Author,book_category from Book_Master 
where book_category='Comp Sc' 
6)


select * from Student_master
select * from Department_master

 select  Stud_Code, subject1, subject2, subject3, 
  subject1+subject2+subject3 as totalmarks      
  from Student_Marks order by totalmarks desc 
  

