1)alter table Department_master add constraint deptname_UQ unique(dept_name)
 SELECT *from Department_master
 SP_HELP 'Department_master'
select *  from sys.indexes where object_id=object_id('Department_master')

2)
delete  Department_master where Dept_code=60 or Dept_code=90
insert into Department_master values(61,'home sciences')
insert into Department_master values(71,'home sciencess')
insert into Department_master values(80,NULL)
insert into Department_master values(90,NULL)
3)
select *from Book_Transaction
select *  from sys.indexes where object_id=object_id('Book_Transaction')
alter table Book_Transaction add constraint book_code_UQ unique(book_code)  
alter table Book_Transaction alter column stud_code    


4)
select *  from sys.indexes 
select *  from sys.indexes where object_id=object_id('Department_master')
5)
 select *  from [dbo].[Desig_master]
 select *  from [dbo].[Department_master]
 select *  from [dbo].[Staff_Master] 





  create view StaffDetails_view1 as select st.Staff_Code,
  st.Staff_Name, Dept_Name,Design_Name, Salary 
 from dbo.Staff_Master st  inner join dbo.Desig_master de
  on st.Des_code=de.Design_code 
  inner  join dbo.Department_master dm on  
  de.Design_Code=dm.Dept_code
  select *from dbo.Staff_Master
  select *from  dbo.Department_master
  select *from dbo.Desig_master

select Staff_Code, Staff_Name, Dept_Name, Design_Name, Salary from StaffDetails_view1
 insert into StaffDetails_view1 values(10047,'mouni','ei',20000) 
6)

insert into staff_172404 values(21435,'sandeep',104,30,'1996-07-11 00:00:00:000','2018-12-12 00:00:00:000',1002159,204520.00,'mumbai')
select * from staff_master
7)
CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL
8)
sp_helptext staff_v2
9)
create view staff_172404 as
select* from Staff_Master where DATENAME(month,hiredate)='June'
10)
CREATE UNIQUE INDEX idx_employees_172404
 ON Employee(Employee_number)
select * from employee

sp_help employee

